#include "SQDictionary.h"
#include "AddWord.h"
#include "SearchWord.h"
#include "DeleteWord.h"
#include "dict.h"

using namespace Project3;
using namespace System;
using namespace System::Windows::Forms;

[STAThreadAttribute]

int main()
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	// main page

	Project3::SQDictionary form;
	Application::Run(% form);
	
}

