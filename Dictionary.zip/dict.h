#pragma once
#include "SQDictionary.h"
#include "AddWord.h"
#include "SearchWord.h"
#include "DeleteWord.h"

using namespace System;
using namespace System::Windows::Forms;
using namespace System::IO;

ref class Node {
public:
	array<Node^>^ children;
	String^ meaning;
	bool EndOfWord;

	Node() 
	{
		children = gcnew array<Node^>(26);
		for (int i = 0; i < 26; i++)
		{
			children[i] = nullptr;
		}
		EndOfWord = false;
	}
};

ref class Trie {
private:
	Node^ root;

public:
	Trie()
	{
		root = gcnew Node();
	}

	int charToIndex(Char c) 
	{
		return c - 'a';
	}

	void insert(String^ word, String^ meaning) 
	{
		Node^ current = root;
		for each (Char c in word) 
		{
			int index = charToIndex(c);
			if (current->children[index] == nullptr) 
			{
				current->children[index] = gcnew Node();
			}
			current = current->children[index];
		}
		current->EndOfWord = true;
		current->meaning = meaning;
		writeDictionary(this, "dictionary.txt");
	}

	Node^ search(String^ word) 
	{
		Node^ current = root;
		for each (Char c in word) 
		{
			int index = charToIndex(c);
			if (current->children[index] == nullptr) 
			{
				return nullptr;
			}
			current = current->children[index];
		}
		return (current != nullptr && current->EndOfWord) ? current : nullptr;
	}
	bool deleteWord(String^ word) {
		Node^ current = root;
		const int MAX_ANCESTORS = 100; 
		array<Node^>^ ancestors = gcnew array<Node^>(MAX_ANCESTORS); 
		int ancestorCount = 0;

		for each (Char c in word)
		{
			int index = charToIndex(c);
			if (current->children[index] == nullptr) 
			{
				return false;
			}
			ancestors[ancestorCount++] = current;
			current = current->children[index];

			// Check if the ancestors array is full (you might want to handle this differently)
			if (ancestorCount >= MAX_ANCESTORS) 
			{
				Console::WriteLine("Ancestors array is full!");
				return false;
			}
		}
		if (!current->EndOfWord)
		{
			return false;
		}

		return true;
	}


	bool updateWord(String^ word, String^ newMeaning) 
	{
		Node^ node = search(word);
		if (node != nullptr) 
		{
			node->meaning = newMeaning;
			return true;
		}
		return false;
	}

	array<String^>^ wordSuggestions(String^ prefix) 
	{
		array<String^>^ suggestions = gcnew array<String^>(10);
		Node^ current = root;

		for each (Char c in prefix)
		{
			int index = charToIndex(c);
			if (current->children[index] == nullptr) 
			{
				return suggestions;
			}
			current = current->children[index];
		}


		int index = 0;
		wordSuggestionsDFS(current, prefix, suggestions, index);

		return suggestions;
	}

	void writeDictionary(Trie^ trie, String^ filename) {
		StreamWriter^ file = gcnew StreamWriter(filename,true);  // true indicates k ye append mode main hai
		if (file != nullptr) 
		{
			writeDictionaryDFS(trie->root, "", file);
			file->Close();
		}
		else {
			Console::WriteLine("Unable to open file ", filename);
		}
	}

	void writeDictionaryDFS(Node^ node, String^ currentPrefix, StreamWriter^ file) {
		if (node->EndOfWord) {
			file->WriteLine("{0} {1}", currentPrefix, node->meaning);
		}

		for (int i = 0; i < 26; i++)
		{
			if (node->children[i] != nullptr) 
			{
				Char nextChar = 'a' + i;
				writeDictionaryDFS(node->children[i], currentPrefix + nextChar, file);
			}
		}
	}

	void wordSuggestionsDFS(Node^ node, String^ currentPrefix, array<String^>^ suggestions, int% index) {
		if (node->EndOfWord)
		{
			suggestions[index++] = currentPrefix;
		}

		for (int i = 0; i < 26; i++)
		{
			if (node->children[i] != nullptr) 
			{
				Char nextChar = 'a' + i;
				wordSuggestionsDFS(node->children[i], currentPrefix + nextChar, suggestions, index);
			}
		}
	}
};
