#include "DeleteWord.h"

